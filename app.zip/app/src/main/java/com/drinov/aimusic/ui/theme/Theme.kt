package com.drinov.aimusic.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val StudioColors = darkColorScheme(
    primary = Color(0xFFB58CFF),
    onPrimary = Color(0xFF210B42),
    secondary = Color(0xFF8D6BE8),
    background = Color(0xFF0B0912),
    surface = Color(0xFF171321),
    surfaceVariant = Color(0xFF282136),
    onBackground = Color(0xFFF7F2FF),
    onSurface = Color(0xFFF7F2FF)
)

@Composable
fun DrinovTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = StudioColors,
        typography = MaterialTheme.typography,
        content = content
    )
}
