package com.drinov.aimusic.domain.repository

import com.drinov.aimusic.domain.model.GenerationRequest
import com.drinov.aimusic.domain.model.GenerationResult

/**
 * API provider boundary. Implement through a secure backend in a later phase.
 * Never embed provider API secrets in the Android application.
 */
interface MusicGenerationProvider {
    suspend fun generate(request: GenerationRequest): Result<GenerationResult>
}
