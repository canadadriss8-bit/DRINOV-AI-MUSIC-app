package com.drinov.aimusic

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.drinov.aimusic.ui.DrinovApp
import com.drinov.aimusic.ui.theme.DrinovTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            DrinovTheme {
                DrinovApp()
            }
        }
    }
}
