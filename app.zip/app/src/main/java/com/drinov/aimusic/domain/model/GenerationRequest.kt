package com.drinov.aimusic.domain.model

data class GenerationRequest(
    val prompt: String,
    val style: String,
    val mood: String,
    val vocal: VocalPreference,
    val languageTag: String
)

enum class VocalPreference { MALE, FEMALE, INSTRUMENTAL }
