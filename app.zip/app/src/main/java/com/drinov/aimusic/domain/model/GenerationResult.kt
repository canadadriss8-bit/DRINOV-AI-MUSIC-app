package com.drinov.aimusic.domain.model

data class GenerationResult(
    val id: String,
    val title: String,
    val audioUrl: String?
)
