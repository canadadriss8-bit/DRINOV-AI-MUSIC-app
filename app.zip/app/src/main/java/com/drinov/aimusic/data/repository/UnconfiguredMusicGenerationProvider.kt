package com.drinov.aimusic.data.repository

import com.drinov.aimusic.domain.model.GenerationRequest
import com.drinov.aimusic.domain.model.GenerationResult
import com.drinov.aimusic.domain.repository.MusicGenerationProvider

/** Safe Phase 1 placeholder: no network request and no fake generated track. */
class UnconfiguredMusicGenerationProvider : MusicGenerationProvider {
    override suspend fun generate(request: GenerationRequest): Result<GenerationResult> =
        Result.failure(IllegalStateException("AI generation is not configured yet."))
}
