package com.drinov.aimusic.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.drinov.aimusic.R

private enum class AppTab { HOME, GENERATOR, LYRICS, LIBRARY, SETTINGS }

@Composable
fun DrinovApp() {
    var selected by rememberSaveable { mutableStateOf(AppTab.HOME) }
    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        bottomBar = {
            NavigationBar(containerColor = Color(0xFF15111F)) {
                val tabs = listOf(
                    AppTab.HOME to R.string.nav_home,
                    AppTab.GENERATOR to R.string.nav_generator,
                    AppTab.LYRICS to R.string.nav_lyrics,
                    AppTab.LIBRARY to R.string.nav_library,
                    AppTab.SETTINGS to R.string.nav_settings
                )
                tabs.forEach { (tab, label) ->
                    NavigationBarItem(
                        selected = selected == tab,
                        onClick = { selected = tab },
                        icon = { Text(tab.symbol(), fontSize = 17.sp) },
                        label = { Text(stringResource(label), fontSize = 10.sp) }
                    )
                }
            }
        }
    ) { padding ->
        when (selected) {
            AppTab.HOME -> HomeScreen(padding) { selected = AppTab.GENERATOR }
            AppTab.GENERATOR -> GeneratorScreen(padding)
            AppTab.LYRICS -> LyricsScreen(padding)
            AppTab.LIBRARY -> LibraryScreen(padding)
            AppTab.SETTINGS -> SettingsScreen(padding)
        }
    }
}

private fun AppTab.symbol() = when (this) {
    AppTab.HOME -> "⌂"
    AppTab.GENERATOR -> "✦"
    AppTab.LYRICS -> "♫"
    AppTab.LIBRARY -> "▤"
    AppTab.SETTINGS -> "⚙"
}

@Composable
private fun ScreenColumn(padding: PaddingValues, content: @Composable () -> Unit) {
    Column(
        modifier = Modifier.fillMaxSize().padding(padding).padding(horizontal = 20.dp, vertical = 18.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) { content() }
}

@Composable
private fun BrandHeader() {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Column {
            Text("DRINOV", color = MaterialTheme.colorScheme.primary, fontSize = 13.sp, fontWeight = FontWeight.Bold, letterSpacing = 3.sp)
            Text("AI MUSIC", color = MaterialTheme.colorScheme.onSurface, fontSize = 25.sp, fontWeight = FontWeight.ExtraBold)
        }
        Spacer(Modifier.weight(1f))
        Text("●", color = MaterialTheme.colorScheme.primary, fontSize = 18.sp)
    }
}

@Composable
private fun HomeScreen(padding: PaddingValues, onCreate: () -> Unit) {
    ScreenColumn(padding) {
        BrandHeader()
        Column(
            modifier = Modifier.fillMaxWidth()
                .background(
                    Brush.linearGradient(listOf(Color(0xFF3B206B), Color(0xFF171225), Color(0xFF241743))),
                    RoundedCornerShape(26.dp)
                ).padding(22.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            Text(stringResource(R.string.home_eyebrow), color = Color(0xFFD5C0FF), fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
            Text(stringResource(R.string.home_title), fontSize = 27.sp, lineHeight = 32.sp, fontWeight = FontWeight.Bold, color = Color.White)
            Text(stringResource(R.string.home_subtitle), color = Color(0xFFD7D0E3), fontSize = 14.sp)
            Button(onClick = onCreate, colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB58CFF))) {
                Text(stringResource(R.string.start_creating), color = Color(0xFF210B42), fontWeight = FontWeight.Bold)
            }
        }
        Text(stringResource(R.string.quick_access), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold)
        FeatureCard("✦", stringResource(R.string.generator_title), stringResource(R.string.generator_desc))
        FeatureCard("♫", stringResource(R.string.lyrics_title), stringResource(R.string.lyrics_desc))
        FeatureCard("▤", stringResource(R.string.library_title), stringResource(R.string.library_desc))
    }
}

@Composable
private fun FeatureCard(icon: String, title: String, description: String) {
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
        Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
            Text(icon, color = MaterialTheme.colorScheme.primary, fontSize = 24.sp)
            Spacer(Modifier.width(14.dp))
            Column {
                Text(title, fontWeight = FontWeight.Bold)
                Text(description, color = Color(0xFFB9B1C7), fontSize = 12.sp)
            }
        }
    }
}

@Composable
private fun GeneratorScreen(padding: PaddingValues) {
    var prompt by rememberSaveable { mutableStateOf("") }
    var style by rememberSaveable { mutableStateOf("") }
    ScreenColumn(padding) {
        BrandHeader()
        Text(stringResource(R.string.generator_title), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(stringResource(R.string.generator_intro), color = Color(0xFFB9B1C7))
        OutlinedTextField(
            value = prompt, onValueChange = { prompt = it }, modifier = Modifier.fillMaxWidth(),
            label = { Text(stringResource(R.string.prompt_label)) },
            placeholder = { Text(stringResource(R.string.prompt_hint)) }, minLines = 4
        )
        OutlinedTextField(
            value = style, onValueChange = { style = it }, modifier = Modifier.fillMaxWidth(),
            label = { Text(stringResource(R.string.style_label)) },
            placeholder = { Text(stringResource(R.string.style_hint)) }
        )
        Text(stringResource(R.string.backend_later_note), color = Color(0xFFD5C0FF), fontSize = 12.sp)
        Button(onClick = {}, enabled = false, modifier = Modifier.fillMaxWidth()) {
            Text(stringResource(R.string.generate_coming_soon))
        }
    }
}

@Composable
private fun LyricsScreen(padding: PaddingValues) {
    var lyrics by rememberSaveable { mutableStateOf("") }
    ScreenColumn(padding) {
        BrandHeader()
        Text(stringResource(R.string.lyrics_title), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Text(stringResource(R.string.lyrics_intro), color = Color(0xFFB9B1C7))
        OutlinedTextField(
            value = lyrics, onValueChange = { lyrics = it }, modifier = Modifier.fillMaxWidth().weight(1f, fill = false),
            label = { Text(stringResource(R.string.lyrics_label)) },
            placeholder = { Text(stringResource(R.string.lyrics_hint)) }, minLines = 12
        )
        TextButton(onClick = { lyrics = "" }) { Text(stringResource(R.string.clear_text)) }
    }
}

@Composable
private fun LibraryScreen(padding: PaddingValues) {
    ScreenColumn(padding) {
        BrandHeader()
        Text(stringResource(R.string.library_title), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)) {
            Column(Modifier.fillMaxWidth().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("♫", color = MaterialTheme.colorScheme.primary, fontSize = 32.sp)
                Text(stringResource(R.string.library_empty_title), fontWeight = FontWeight.Bold)
                Text(stringResource(R.string.library_empty_desc), color = Color(0xFFB9B1C7))
            }
        }
    }
}

@Composable
private fun SettingsScreen(padding: PaddingValues) {
    ScreenColumn(padding) {
        BrandHeader()
        Text(stringResource(R.string.settings_title), style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
        FeatureCard("文", stringResource(R.string.language_title), stringResource(R.string.language_desc))
        FeatureCard("◐", stringResource(R.string.appearance_title), stringResource(R.string.appearance_desc))
        FeatureCard("⌑", stringResource(R.string.privacy_title), stringResource(R.string.privacy_desc))
        Text(stringResource(R.string.language_system_note), color = Color(0xFFB9B1C7), fontSize = 12.sp)
    }
}
