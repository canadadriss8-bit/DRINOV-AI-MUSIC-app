package com.drinov.aimusic.data.repository

import com.drinov.aimusic.domain.model.GenerationRequest
import com.drinov.aimusic.domain.model.VocalPreference
import kotlinx.coroutines.runBlocking
import org.junit.Assert.assertTrue
import org.junit.Test

class UnconfiguredMusicGenerationProviderTest {
    @Test
    fun generateFailsClearlyUntilBackendIsConfigured() = runBlocking {
        val provider = UnconfiguredMusicGenerationProvider()
        val result = provider.generate(
            GenerationRequest(
                prompt = "Moroccan rai song",
                style = "Rai",
                mood = "Hopeful",
                vocal = VocalPreference.FEMALE,
                languageTag = "ar"
            )
        )
        assertTrue(result.isFailure)
    }
}
